import random
r_eating = "I don't like eating anything because I'am a bot"

def unknown():
    response = ["could you please re-place that?",
                ".........",
                "I can't under stand you",
                "What does that mean?"][random.randrange(4)]
    return response